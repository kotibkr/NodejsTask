var ctgryMdl = require(appRoot + '/server/api/modules/category/models/ctgryMdl');

/*******************************************************
 * Controller   : categoryProduct
 * Parameters   : req,res()
 * description  : to delete product based on category id
 * 20/03/2020   : KOTESWARARAO BORIGARLA - Initial Function
 * 
 * ****************************************************/
exports.categoryProduct = function (req, res) {
    ctgryMdl.categoryMdl(req.params.ctgry_id, req.params.user_id)
        .then(function (ctgryResult) {
            ctgryMdl.productMdl(req.params.ctgry_id, req.params.user_id)
                .then(function (productResult) {
                    ctgryMdl.deletedRecordsMdl(req.params.ctgry_id)
                        .then(function (deletedResult) {
                            res.send({ "status": '200', "message": 'Record Deleted Successfully...!!!', "data": deletedResult });
                        }).catch(function (error) {
                            res.send({ "status": 700, "message": "Internal Database Error", "data": error });
                        });
                }).catch(function (error) {
                    res.send({ "status": 700, "message": "Internal Database Error", "data": error });
                });
        }).catch(function (error) {
            res.send({ "status": 700, "message": "Internal Database Error", "data": error });
        });
}

