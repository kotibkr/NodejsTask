var sqldb = require(appRoot + '/config/db.config');
var connection = sqldb.MySQLConPool;

/*****************************************************************************
* Function      : categoryMdl
* Description   : 
* Arguments     : Promise return
******************************************************************************/
exports.categoryMdl = function (ctgry_id, user_id) {
    console.log(user_id)
    return new Promise(function (resolve, reject) {
        
        var QRY_TO_EXEC = `UPDATE ctgry_lst_t SET a_in = 0, updte_usr_id = ${user_id}, u_ts = CURRENT_TIMESTAMP() where ctgry_id = ${ctgry_id}`;

        connection.query(QRY_TO_EXEC, function (err, rows) {
            if (err) {
                return reject(err);
            } else {
                resolve(rows);
            }
        });
    });
};

/*****************************************************************************
* Function      : categoryMdl
* Description   : 
* Arguments     : Promise return
******************************************************************************/
exports.productMdl = function (ctgry_id, user_id) {

    return new Promise(function (resolve, reject) {
        
        var QRY_TO_EXEC = `UPDATE prdct_lst_t SET a_in = 0, updte_usr_id = ${user_id}, u_ts = CURRENT_TIMESTAMP() where ctgry_id = ${ctgry_id}`;

        connection.query(QRY_TO_EXEC, function (err, rows) {
            if (err) {
                return reject(err);
            } else {
                resolve(rows);
            }
        });
    });
};

/*****************************************************************************
* Function      : deletedRecordsMdl
* Description   : 
* Arguments     : Promise return
******************************************************************************/
exports.deletedRecordsMdl = function (ctgry_id) {

    return new Promise(function (resolve, reject) {
        
        var QRY_TO_EXEC = `SELECT c.ctgry_id,c.ctgry_nm,p.prdct_id,p.prdct_nm,u.usr_nm
        FROM ctgry_lst_t c
        JOIN prdct_lst_t p ON c.ctgry_id = c.ctgry_id
        JOIN usr_lst_t u ON u.usr_id = p.updte_usr_id
        WHERE c.ctgry_id = ${ctgry_id} and c.a_in = 0 and p.a_in = 0
        ORDER BY c.ctgry_id,p.prdct_id `;

        connection.query(QRY_TO_EXEC, function (err, rows) {
            console.log(err)
            if (err) {
                return reject(err);
            } else {
                resolve(rows);
            }
        });
    });
};
