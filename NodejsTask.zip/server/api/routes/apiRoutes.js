var express = require('express');
var router = express.Router();

var ctgryCtrl = require('../modules/category/controllers/ctgryCtrl');

router.delete('/category/:ctgry_id/:user_id', ctgryCtrl.categoryProduct);

module.exports = router;