var http = require('http');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');

appRoot = __dirname;
var sqldb = require(appRoot + '/config/db.config');
// get connection from Connection Pool
sqldb.MySQLConPool.getConnection(function (err, connection) {
    if (err) {
        console.log("Can not get the connection from Datastore");
    } else {
        console.log('You are now connected with mysql database...')
    }
});

app.use(bodyParser.json());       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
    extended: true
}));

app.use(function (req, res, next) {
    // res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'DELETE');
    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // response headers you wish to expose
    res.setHeader('Access-Control-Expose-Headers', 'x-access-token');
    // Set to true if you need the website to include cookies in the requests sent
    res.setHeader('Access-Control-Allow-Credentials', true);
    // Pass to next layer of middleware
    next();
});

app.use('/apiv1', require('./server/api/routes/apiRoutes'));

var server = app.listen(3000, "127.0.0.1", function () {
    var host = server.address().address
    var port = server.address().port
    console.log("Task is listening at http://%s:%s", host, port)
});