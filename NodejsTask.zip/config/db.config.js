var mysql = require('mysql')


var MySQLConPool = {};

var USER = 'root';
var PWD = '';
var DATABASE = 'testdb';
var DB_HOST_NAME = '127.0.0.1';
var DB_PORT = '3306';

var MySQLConPool = mysql.createPool({
       host: DB_HOST_NAME,
       user: USER,
       password: PWD,
       port: DB_PORT,
       database: DATABASE,
       acquireTimeout: 5000,
       debug: false,
});


MySQLConPool.on('acquire', function (connection) {
       // console.log('Database Connection Acquired', connection.threadId);
});
MySQLConPool.on('release', function (connection) {
       // console.log('Database Connection Released', connection.threadId);
});
MySQLConPool.on('enqueue', function () {
       //  console.log('Waiting for available connection slot');
});

exports.MySQLConPool = MySQLConPool;

  