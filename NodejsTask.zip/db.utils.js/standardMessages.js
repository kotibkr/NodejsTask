/********************************************************************************************
Description       : All the standard messages and codes used in the application are listed here.
********************************************************************************************/
// var moment = require('moment');
var STD_DATE_FORMAT = "YYYY-MM-DD";
var message = {
    "SUCCESS": { "code": 200, "message": null }
    , "LIMIT_EXCEED_ERROR": { "code": 600, "message": "Query Limit Exceeded Error" }
    , "INVALID_QUERY_PERMS": { "code": 600, "message": "Invalid Parameters send" }
    , "MODEL_ERR": { "code": 700, "message": "Internal Database Error" }
    , "IVALID_DATA": { "code": 601, "message": "Internal Data Provided" }
    , "UN_REQ_FIELDS": { "code": 601, "message": "Invalid parameters send" }
    , "DB_CONNECTION_ISSUE": { "code": 700, "message": "Database Query/Connection Error" }
    , "DB_QUERY_ISSUE": { "code": 700, "message": "Database Query/Connection Error" }
};

exports.message = message;
